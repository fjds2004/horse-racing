//
//  horse_raceTests.swift
//  horse raceTests
//
//  Created by Frankie Docking Smith on 21/12/2024.
//

import Testing
@testable import horse_race

struct horse_raceTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
